const { onRequest } = require('firebase-functions/v2/https');
const app = require('./src/app');

// Une seule fonction HTTPS qui sert toute l'API Express.
// Firebase Hosting redirige /api/** vers cette fonction (voir firebase.json).
exports.api = onRequest({ region: 'europe-west1', memory: '256MiB' }, app);
