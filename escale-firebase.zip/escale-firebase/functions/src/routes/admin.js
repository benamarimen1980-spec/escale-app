const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../firestore');

const router = express.Router();

const SEED_USERS = [
  { nom: 'S. Bouazizi', email: 'admin@escale.tn', role: 'admin', service: 'Direction Générale' },
  { nom: 'M. Trabelsi', email: 'achats@escale.tn', role: 'achats', service: 'Achats & Approvisionnement' },
  { nom: 'H. Cherni', email: 'logistique@escale.tn', role: 'logistique', service: 'Logistique & Transit' },
  { nom: 'N. Jendoubi', email: 'finance@escale.tn', role: 'finance', service: 'Comptabilité & Finance' },
];

const SEED_DOSSIERS = [
  {
    ref: 'IMP-2026-0031', fournisseur: 'Shandong Heavy Industries', pays: 'Chine', incoterm: 'FOB', devise: 'USD',
    deviseFrais: 'TND', tauxPrev: 3.11, tauxReel: null, statut: 'transit', createdAt: '2026-06-15T09:00:00.000Z',
    articles: [{ designation: 'Moteurs électriques 15kW', qte: 40, pu: 410 }, { designation: 'Variateurs de fréquence', qte: 60, pu: 145 }],
    transport: { mode: 'Maritime', bl: 'MSCU7741029', navire: 'MSC Elodie', conteneurs: ['MSCU7741029', 'MSCU7741030'] },
    milestones: { etd: '2026-07-05', atd: '2026-07-06', etaOrig: '2026-08-10', eta: '2026-08-10', ata: null, dedouanementPrev: '2026-08-16', dedouanementReel: null, livraisonPrev: '2026-08-20', livraisonReel: null },
    frais: { fret: { est: 4200, reel: 4200 }, assurance: { est: 380, reel: 380 }, douane: { est: 6100, reel: null }, magasinage: { est: 0, reel: null }, transitaire: { est: 650, reel: 650 }, transportLocal: { est: 300, reel: null } },
    paiements: [{ type: 'Acompte', pct: 30, base: 'commande', delai: 0, dateBase: '2026-06-20' }, { type: 'Solde', pct: 70, base: 'eta', delai: 30, dateBase: null }],
  },
  {
    ref: 'IMP-2026-0032', fournisseur: 'AnatoliaSteel A.Ş.', pays: 'Turquie', incoterm: 'CIF', devise: 'EUR',
    deviseFrais: 'TND', tauxPrev: 3.38, tauxReel: 3.41, statut: 'douane', createdAt: '2026-06-05T09:00:00.000Z',
    articles: [{ designation: 'Tôles acier galvanisé', qte: 1200, pu: 38 }],
    transport: { mode: 'Maritime', bl: 'ONEY5512837', navire: 'ONE Innovation', conteneurs: ['ONEU5512837'] },
    milestones: { etd: '2026-07-01', atd: '2026-07-01', etaOrig: '2026-07-28', eta: '2026-08-02', ata: '2026-08-03', dedouanementPrev: '2026-08-07', dedouanementReel: null, livraisonPrev: '2026-08-11', livraisonReel: null },
    frais: { fret: { est: 2600, reel: 2750 }, assurance: { est: 410, reel: 410 }, douane: { est: 9800, reel: 9950 }, magasinage: { est: 0, reel: 1200 }, transitaire: { est: 520, reel: 520 }, transportLocal: { est: 280, reel: 280 } },
    paiements: [{ type: 'Acompte', pct: 20, base: 'commande', delai: 0, dateBase: '2026-06-10' }, { type: 'Solde', pct: 80, base: 'bl', delai: 45, dateBase: null }],
  },
  {
    ref: 'IMP-2026-0033', fournisseur: 'Bergmann Präzision GmbH', pays: 'Allemagne', incoterm: 'EXW', devise: 'EUR',
    deviseFrais: 'TND', tauxPrev: 3.36, tauxReel: null, statut: 'preparation', createdAt: '2026-08-01T09:00:00.000Z',
    articles: [{ designation: 'Pièces de rechange CNC', qte: 8, pu: 1650 }, { designation: 'Roulements industriels', qte: 300, pu: 22 }],
    transport: { mode: 'Aérien', bl: 'LTA-020-88213456', navire: 'LH 1180', conteneurs: [] },
    milestones: { etd: null, atd: null, etaOrig: '2026-08-25', eta: '2026-08-25', ata: null, dedouanementPrev: '2026-08-27', dedouanementReel: null, livraisonPrev: '2026-08-29', livraisonReel: null },
    frais: { fret: { est: 2100, reel: null }, assurance: { est: 120, reel: null }, douane: { est: 2400, reel: null }, magasinage: { est: 0, reel: null }, transitaire: { est: 300, reel: null }, transportLocal: { est: 150, reel: null } },
    paiements: [{ type: 'Solde', pct: 100, base: 'commande', delai: 60, dateBase: '2026-08-01' }],
  },
  {
    ref: 'IMP-2026-0035', fournisseur: 'Nordic Pack AB', pays: 'Suède', incoterm: 'FOB', devise: 'EUR',
    deviseFrais: 'TND', tauxPrev: 3.35, tauxReel: null, statut: 'port', createdAt: '2026-07-10T09:00:00.000Z',
    articles: [{ designation: "Films d'emballage industriel", qte: 500, pu: 64 }],
    transport: { mode: 'Maritime', bl: 'MAEU9902141', navire: 'Maersk Halden', conteneurs: ['MAEU9902141'] },
    milestones: { etd: '2026-07-20', atd: '2026-07-21', etaOrig: '2026-08-12', eta: '2026-08-12', ata: '2026-08-12', dedouanementPrev: '2026-08-15', dedouanementReel: null, livraisonPrev: '2026-08-19', livraisonReel: null },
    frais: { fret: { est: 3100, reel: 3100 }, assurance: { est: 290, reel: 290 }, douane: { est: 5900, reel: null }, magasinage: { est: 0, reel: 640 }, transitaire: { est: 480, reel: 480 }, transportLocal: { est: 220, reel: null } },
    paiements: [{ type: 'Solde', pct: 100, base: 'bl', delai: 25, dateBase: null }],
  },
];

// GET /api/admin/seed?key=...
// Protégé par la variable d'environnement SEED_KEY. N'insère les données que si la
// collection "users" est vide (idempotent) — sans danger de ré-exécution accidentelle.
router.get('/seed', async (req, res) => {
  try {
    const expected = process.env.SEED_KEY;
    if (!expected) return res.status(500).json({ error: "SEED_KEY n'est pas configurée côté serveur." });
    if (req.query.key !== expected) return res.status(403).json({ error: 'Clé invalide.' });

    const existing = await db.collection('users').limit(1).get();
    if (!existing.empty) {
      return res.status(409).json({ error: 'Des données existent déjà — amorçage ignoré (protection anti double-exécution).' });
    }

    const batch = db.batch();
    SEED_USERS.forEach(u => {
      const ref = db.collection('users').doc();
      batch.set(ref, { ...u, passwordHash: bcrypt.hashSync('demo1234', 10) });
    });
    SEED_DOSSIERS.forEach(d => {
      const ref = db.collection('dossiers').doc();
      batch.set(ref, d);
    });
    await batch.commit();

    res.json({ ok: true, message: `${SEED_USERS.length} utilisateurs et ${SEED_DOSSIERS.length} dossiers créés.` });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur lors de l\'amorçage.' });
  }
});

module.exports = router;
