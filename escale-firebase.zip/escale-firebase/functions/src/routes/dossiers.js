const express = require('express');
const { db } = require('../firestore');
const { requireAuth, requireRole } = require('../middleware/auth');
const data = require('../data');

const router = express.Router();
router.use(requireAuth);

async function logAction(req, action, entityId, details) {
  await db.collection('auditLog').add({
    userId: req.user.id, userNom: req.user.nom, action, entity: 'dossier',
    entityId: entityId || null, details: details || null, timestamp: new Date().toISOString(),
  });
}

router.get('/', async (req, res) => {
  try { res.json({ dossiers: await data.listDossiers(db) }); }
  catch (e) { console.error(e); res.status(500).json({ error: 'Erreur serveur.' }); }
});

router.get('/:id', async (req, res) => {
  const d = await data.getDossier(db, req.params.id);
  if (!d) return res.status(404).json({ error: 'Dossier introuvable.' });
  res.json({ dossier: d });
});

router.post('/', requireRole('achats'), async (req, res) => {
  const b = req.body || {};
  if (!b.ref || !b.fournisseur || !b.incoterm || !b.devise) {
    return res.status(400).json({ error: 'Champs requis manquants (référence, fournisseur, incoterm, devise).' });
  }
  if (await data.refExists(db, b.ref)) {
    return res.status(409).json({ error: `La référence ${b.ref} existe déjà.` });
  }
  try {
    const dossier = await data.createDossier(db, b, req.user.id);
    await logAction(req, 'Création dossier', dossier.id, b.ref);
    res.status(201).json({ dossier });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Erreur serveur.' }); }
});

router.put('/:id', requireRole('achats'), async (req, res) => {
  const existing = await data.getDossier(db, req.params.id);
  if (!existing) return res.status(404).json({ error: 'Dossier introuvable.' });
  const dossier = await data.updateDossierAchats(db, req.params.id, req.body || {});
  await logAction(req, 'Modification dossier (Achats)', req.params.id, existing.ref);
  res.json({ dossier });
});

router.put('/:id/logistique', requireRole('logistique'), async (req, res) => {
  const existing = await data.getDossier(db, req.params.id);
  if (!existing) return res.status(404).json({ error: 'Dossier introuvable.' });
  const dossier = await data.updateDossierLogistique(db, req.params.id, req.body || {});
  await logAction(req, 'Mise à jour logistique', req.params.id, JSON.stringify(req.body?.milestones || req.body?.transport || {}));
  res.json({ dossier });
});

router.post('/:id/logistique/simuler-retard', requireRole('logistique'), async (req, res) => {
  const jours = Number(req.body?.jours) || 5;
  const dossier = await data.simulerRetardEta(db, req.params.id, jours);
  if (!dossier) return res.status(404).json({ error: 'Dossier introuvable.' });
  await logAction(req, 'Simulation retard ETA', req.params.id, `+${jours}j`);
  res.json({ dossier });
});

router.post('/:id/logistique/reinitialiser-eta', requireRole('logistique'), async (req, res) => {
  const dossier = await data.reinitialiserEta(db, req.params.id);
  if (!dossier) return res.status(404).json({ error: 'Dossier introuvable.' });
  await logAction(req, 'Réinitialisation ETA', req.params.id, null);
  res.json({ dossier });
});

router.put('/:id/finance', requireRole('finance'), async (req, res) => {
  const dossier = await data.updateDossierFinance(db, req.params.id, req.body || {});
  if (!dossier) return res.status(404).json({ error: 'Dossier introuvable.' });
  await logAction(req, 'Saisie frais réels / finance', req.params.id, JSON.stringify(req.body?.frais || {}));
  res.json({ dossier });
});

router.delete('/:id', async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Suppression réservée au profil Admin.' });
  const existing = await data.getDossier(db, req.params.id);
  if (!existing) return res.status(404).json({ error: 'Dossier introuvable.' });
  await data.deleteDossier(db, req.params.id);
  await logAction(req, 'Suppression dossier', req.params.id, existing.ref);
  res.json({ ok: true });
});

module.exports = router;
