const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../firestore');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', requireRole('admin'), async (req, res) => {
  const snap = await db.collection('users').orderBy('nom').get();
  const users = snap.docs.map(d => { const u = d.data(); return { id: d.id, nom: u.nom, email: u.email, role: u.role, service: u.service }; });
  res.json({ users });
});

router.post('/', requireRole('admin'), async (req, res) => {
  const { nom, email, password, role, service } = req.body || {};
  if (!nom || !email || !password || !role) return res.status(400).json({ error: 'Champs requis manquants.' });
  if (!['admin', 'achats', 'logistique', 'finance'].includes(role)) return res.status(400).json({ error: 'Rôle invalide.' });

  const normalizedEmail = email.toLowerCase().trim();
  const exists = await db.collection('users').where('email', '==', normalizedEmail).limit(1).get();
  if (!exists.empty) return res.status(409).json({ error: 'Cet email existe déjà.' });

  const doc = { nom, email: normalizedEmail, passwordHash: bcrypt.hashSync(password, 10), role, service: service || null };
  const ref = await db.collection('users').add(doc);

  await db.collection('auditLog').add({
    userId: req.user.id, userNom: req.user.nom, action: 'Création utilisateur', entity: 'user',
    entityId: ref.id, timestamp: new Date().toISOString(),
  });

  res.status(201).json({ user: { id: ref.id, nom, email: normalizedEmail, role, service } });
});

router.get('/audit-log', requireRole('admin'), async (req, res) => {
  const snap = await db.collection('auditLog').orderBy('timestamp', 'desc').limit(100).get();
  res.json({ log: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
});

module.exports = router;
