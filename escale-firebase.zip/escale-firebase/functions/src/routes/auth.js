const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../firestore');
const { requireAuth, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis.' });

    const snap = await db.collection('users').where('email', '==', email.toLowerCase().trim()).limit(1).get();
    if (snap.empty) return res.status(401).json({ error: 'Identifiants incorrects.' });

    const doc = snap.docs[0];
    const user = { id: doc.id, ...doc.data() };
    if (!bcrypt.compareSync(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Identifiants incorrects.' });
    }

    const token = jwt.sign(
      { id: user.id, nom: user.nom, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    await db.collection('auditLog').add({
      userId: user.id, userNom: user.nom, action: 'Connexion', entity: 'auth', timestamp: new Date().toISOString(),
    });

    res.json({ token, user: { id: user.id, nom: user.nom, email: user.email, role: user.role, service: user.service } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.get('/me', requireAuth, async (req, res) => {
  const doc = await db.collection('users').doc(req.user.id).get();
  if (!doc.exists) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  const u = doc.data();
  res.json({ user: { id: doc.id, nom: u.nom, email: u.email, role: u.role, service: u.service } });
});

module.exports = router;
