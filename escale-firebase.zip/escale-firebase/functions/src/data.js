const FRAIS_TYPES = ['fret', 'assurance', 'douane', 'magasinage', 'transitaire', 'transportLocal'];

function emptyFrais(source) {
  const out = {};
  FRAIS_TYPES.forEach(t => {
    const est = Number(source?.[t]) || 0;
    out[t] = { est, reel: null };
  });
  return out;
}

function parseConteneurs(input) {
  if (Array.isArray(input)) return input;
  return (input || '').toString().split(',').map(s => s.trim()).filter(Boolean);
}

function hydrate(dossier) {
  if (!dossier) return dossier;
  return {
    ...dossier,
    articles: (dossier.articles || []).map(a => ({ ...a, valeur: (Number(a.qte) || 0) * (Number(a.pu) || 0) })),
  };
}

async function listDossiers(db) {
  const snap = await db.collection('dossiers').orderBy('createdAt', 'desc').get();
  return snap.docs.map(doc => hydrate({ id: doc.id, ...doc.data() }));
}

async function getDossier(db, id) {
  const doc = await db.collection('dossiers').doc(id).get();
  if (!doc.exists) return null;
  return hydrate({ id: doc.id, ...doc.data() });
}

async function refExists(db, ref) {
  const snap = await db.collection('dossiers').where('ref', '==', ref).limit(1).get();
  return !snap.empty;
}

async function createDossier(db, body, userId) {
  const articles = (body.articles || []).filter(a => a.designation).map(a => ({
    designation: a.designation, qte: Number(a.qte) || 0, pu: Number(a.pu) || 0,
  }));
  const paiements = (body.paiements || []).map(p => ({
    type: p.type || 'Solde', pct: Number(p.pct) || 0, base: p.base || 'eta', delai: Number(p.delai) || 0, dateBase: p.dateBase || null,
  }));

  const doc = {
    ref: body.ref, fournisseur: body.fournisseur, pays: body.pays || null,
    incoterm: body.incoterm, devise: body.devise, deviseFrais: body.deviseFrais || 'TND',
    tauxPrev: body.tauxPrev || null, tauxReel: null, statut: 'preparation',
    createdBy: userId, createdAt: new Date().toISOString(),
    articles,
    transport: {
      mode: body.transport?.mode || 'Maritime', bl: body.transport?.bl || null,
      navire: body.transport?.navire || null, conteneurs: parseConteneurs(body.transport?.conteneurs),
    },
    milestones: {
      etd: body.milestones?.etd || null, atd: null,
      etaOrig: body.milestones?.eta || null, eta: body.milestones?.eta || null, ata: null,
      dedouanementPrev: body.milestones?.dedouanementPrev || null, dedouanementReel: null,
      livraisonPrev: body.milestones?.livraisonPrev || null, livraisonReel: null,
    },
    frais: emptyFrais(body.frais),
    paiements,
  };

  const ref = await db.collection('dossiers').add(doc);
  return hydrate({ id: ref.id, ...doc });
}

async function updateDossierAchats(db, id, body) {
  const patch = {};
  if (body.fournisseur !== undefined) patch.fournisseur = body.fournisseur;
  if (body.pays !== undefined) patch.pays = body.pays;
  if (body.incoterm !== undefined) patch.incoterm = body.incoterm;
  if (body.devise !== undefined) patch.devise = body.devise;
  if (body.tauxPrev !== undefined) patch.tauxPrev = body.tauxPrev;
  if (Array.isArray(body.articles)) {
    patch.articles = body.articles.filter(a => a.designation).map(a => ({
      designation: a.designation, qte: Number(a.qte) || 0, pu: Number(a.pu) || 0,
    }));
  }
  if (Array.isArray(body.paiements)) {
    patch.paiements = body.paiements.map(p => ({
      type: p.type || 'Solde', pct: Number(p.pct) || 0, base: p.base || 'eta', delai: Number(p.delai) || 0, dateBase: p.dateBase || null,
    }));
  }
  await db.collection('dossiers').doc(id).update(patch);
  return getDossier(db, id);
}

async function updateDossierLogistique(db, id, body) {
  const current = await getDossier(db, id);
  if (!current) return null;
  const patch = {};
  if (body.transport) {
    patch.transport = {
      mode: body.transport.mode ?? current.transport?.mode,
      bl: body.transport.bl ?? current.transport?.bl,
      navire: body.transport.navire ?? current.transport?.navire,
      conteneurs: body.transport.conteneurs !== undefined ? parseConteneurs(body.transport.conteneurs) : current.transport?.conteneurs,
    };
  }
  if (body.milestones) {
    patch.milestones = { ...current.milestones, ...body.milestones };
  }
  if (body.statut) patch.statut = body.statut;
  await db.collection('dossiers').doc(id).update(patch);
  return getDossier(db, id);
}

async function simulerRetardEta(db, id, jours) {
  const current = await getDossier(db, id);
  if (!current) return null;
  const addDays = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r.toISOString().slice(0, 10); };
  const newEta = addDays(current.milestones.eta, jours);
  await db.collection('dossiers').doc(id).update({ 'milestones.eta': newEta });
  return getDossier(db, id);
}

async function reinitialiserEta(db, id) {
  const current = await getDossier(db, id);
  if (!current) return null;
  await db.collection('dossiers').doc(id).update({ 'milestones.eta': current.milestones.etaOrig });
  return getDossier(db, id);
}

async function updateDossierFinance(db, id, body) {
  const current = await getDossier(db, id);
  if (!current) return null;
  const patch = {};
  if (body.frais) {
    const frais = { ...current.frais };
    Object.entries(body.frais).forEach(([type, vals]) => {
      frais[type] = { est: vals.est ?? frais[type]?.est ?? 0, reel: vals.reel === undefined ? (frais[type]?.reel ?? null) : vals.reel };
    });
    patch.frais = frais;
  }
  if (body.tauxReel !== undefined) patch.tauxReel = body.tauxReel;
  if (body.statut) patch.statut = body.statut;
  await db.collection('dossiers').doc(id).update(patch);
  return getDossier(db, id);
}

async function deleteDossier(db, id) {
  await db.collection('dossiers').doc(id).delete();
}

module.exports = {
  FRAIS_TYPES, listDossiers, getDossier, refExists, createDossier,
  updateDossierAchats, updateDossierLogistique, updateDossierFinance,
  simulerRetardEta, reinitialiserEta, deleteDossier,
};
