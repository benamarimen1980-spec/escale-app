const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const dossierRoutes = require('./routes/dossiers');
const dashboardRoutes = require('./routes/dashboard');
const userRoutes = require('./routes/users');
const exportRoutes = require('./routes/exports');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'ESCALE API (Firebase)' }));

app.use('/api/auth', authRoutes);
app.use('/api/dossiers', dossierRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/users', userRoutes);
app.use('/api/exports', exportRoutes);
app.use('/api/admin', adminRoutes);

app.use((req, res) => res.status(404).json({ error: 'Route inconnue.' }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Erreur serveur.' });
});

module.exports = app;
