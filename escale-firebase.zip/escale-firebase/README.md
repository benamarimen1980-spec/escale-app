# ESCALE — Déploiement Firebase

Version de l'application déployable sur Firebase : **Hosting** (frontend statique) + **Cloud Functions 2ᵉ génération** (API Express) + **Firestore** (base de données), accessible depuis n'importe quel navigateur, par plusieurs utilisateurs simultanément.

## Ce qui a changé par rapport à la version locale (SQLite)

La version précédente utilisait SQLite (fichier local), incompatible avec l'environnement serverless de Firebase Functions (système de fichiers éphémère, pas de partage entre utilisateurs). Toute la couche de données a été migrée vers **Firestore** :

- `functions/src/data.js` — accès aux dossiers (créer/lire/modifier/supprimer) via Firestore au lieu de SQL
- `functions/src/logic.js` — la logique métier (Landed Cost, échéancier, alertes, KPIs) est restée identique, elle est simplement passée en fonctions pures qui reçoivent la liste des dossiers déjà chargée
- `functions/src/routes/*.js` — mêmes routes et mêmes règles RBAC qu'avant, adaptées en async/await pour Firestore
- Les identifiants de dossiers/utilisateurs sont maintenant des chaînes (IDs Firestore) plutôt que des entiers

Toute la logique a été testée avec un mock Firestore en mémoire simulant l'API réelle (authentification, RBAC par rôle, création de dossier, simulation de retard ETA avec recalcul automatique de la trésorerie, exports Excel/PDF réels) avant livraison.

## Prérequis

- Un compte Google et un projet Firebase (créez-en un sur [console.firebase.google.com](https://console.firebase.google.com) si vous n'en avez pas — c'est gratuit).
- Sur ce projet, activez **Firestore Database** (mode production) et passez au forfait **Blaze** (paiement à l'usage) — requis pour utiliser Cloud Functions, mais le trafic d'un prototype reste dans les quotas gratuits mensuels dans l'immense majorité des cas.
- Node.js installé sur votre machine.

## Étapes de déploiement

### 1. Installer les outils Firebase et vous connecter

```bash
npm install -g firebase-tools
firebase login
```

Cette étape ouvre votre navigateur pour vous authentifier avec votre compte Google — je ne peux pas la faire à votre place.

### 2. Relier ce projet à votre projet Firebase

Éditez le fichier `.firebaserc` à la racine et remplacez `REMPLACEZ-PAR-VOTRE-PROJECT-ID` par l'identifiant de votre projet Firebase (visible dans les paramètres du projet sur la console). Ou bien :

```bash
firebase use --add
```
et suivez les instructions interactives.

### 3. Configurer les secrets

```bash
cd functions
cp .env.example .env
```

Éditez `.env` et remplacez les deux valeurs par des chaînes aléatoires uniques (par exemple avec `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`, à exécuter deux fois pour obtenir deux valeurs différentes).

### 4. Installer les dépendances

```bash
cd functions
npm install
```

### 5. Déployer

```bash
cd ..
firebase deploy
```

Ceci déploie Hosting, la Cloud Function `api`, et les règles Firestore. À la fin, Firebase affiche l'URL publique de votre app (du type `https://votre-projet.web.app`) — c'est le lien à partager avec les autres utilisateurs.

### 6. Amorcer les données de démonstration (une seule fois)

Une fois déployé, appelez l'URL suivante une seule fois dans votre navigateur ou avec `curl` (remplacez les valeurs) :

```
https://votre-projet.web.app/api/admin/seed?key=VOTRE_SEED_KEY
```

où `VOTRE_SEED_KEY` est la valeur que vous avez mise dans `.env`. Cette route est protégée (clé requise) et refuse de s'exécuter une seconde fois si des données existent déjà — vous ne risquez pas de tout réinitialiser par erreur.

Cela crée 4 comptes de démonstration (mot de passe `demo1234`) :

| Email | Rôle |
|---|---|
| admin@escale.tn | Admin / Direction |
| achats@escale.tn | Service Achats |
| logistique@escale.tn | Service Logistique |
| finance@escale.tn | Comptabilité / Finance |

**Pensez à changer ces mots de passe** (ou créer de nouveaux comptes et supprimer ceux-ci) avant un usage réel, via le module Utilisateurs (profil Admin).

## Vérifier avant de partager le lien

- Ouvrez l'URL Hosting, connectez-vous avec `admin@escale.tn` / `demo1234`.
- Vérifiez que le Dashboard affiche bien les 4 dossiers de démonstration.
- Testez la création d'un dossier (module Achats) et la simulation de retard ETA (module Logistique) pour confirmer que tout communique bien avec Firestore.

## Tester en local avant de déployer (optionnel mais recommandé)

Firebase fournit un émulateur local qui simule Firestore et Functions sans toucher à votre projet réel :

```bash
firebase emulators:start
```

L'interface s'ouvre sur `http://localhost:4000` (émulateurs) et votre app sur le port indiqué par Hosting dans la sortie de la commande.

## Structure du projet

```
escale-firebase/
├── firebase.json          configuration Hosting + Functions + Firestore
├── firestore.rules         accès direct au client bloqué (tout passe par l'API)
├── firestore.indexes.json
├── .firebaserc             ⚠️ à éditer avec votre project ID
├── functions/
│   ├── .env.example         ⚠️ à copier en .env et compléter
│   ├── index.js             point d'entrée de la Cloud Function
│   └── src/
│       ├── app.js           application Express (toutes les routes /api/*)
│       ├── firestore.js     client Firestore partagé
│       ├── data.js          accès aux données des dossiers (Firestore)
│       ├── logic.js         Landed Cost, échéancier, alertes, KPIs (logique pure)
│       ├── middleware/auth.js
│       └── routes/          auth, dossiers, dashboard, users, exports, admin (seed)
└── public/
    └── index.html            frontend (aucune compilation nécessaire)
```

## Limites à connaître

- **Coût** : le forfait Blaze est payant à l'usage, mais Firebase offre un quota gratuit mensuel généreux (2M invocations Functions, 50K lectures/20K écritures Firestore par jour, etc.) largement suffisant pour un prototype ou une petite équipe. Surveillez l'onglet Facturation de la console si l'usage grandit.
- **Firestore n'est pas SQL** : pas de jointures ni d'agrégats serveur — tous les calculs (KPIs, alertes, Landed Cost) se font dans le code de la Cloud Function après avoir chargé les dossiers, ce qui reste très bien pour un volume de quelques centaines à quelques milliers de dossiers, mais ne s'adapte pas indéfiniment sans revoir la stratégie de requêtage.
- **Le jeton d'authentification reste en mémoire côté frontend** (pas de `localStorage`) — une reconnexion est nécessaire après un rechargement de page.
- La route `/api/admin/seed` reste accessible en production (protégée par clé secrète). Vous pouvez la supprimer de `functions/src/app.js` après le premier amorçage si vous préférez ne pas la laisser en place.

## Prochaines étapes suggérées

- Domaine personnalisé (Firebase Hosting le permet gratuitement, avec certificat SSL automatique).
- Migrer `JWT_SECRET`/`SEED_KEY` vers Secret Manager (`firebase functions:secrets:set`) plutôt qu'un fichier `.env`, pour une meilleure sécurité en production.
- Ajouter Firebase Authentication (à la place du système JWT maison) si vous voulez la connexion Google/Microsoft en un clic.
